"use client";

import { Calendar, momentLocalizer } from "react-big-calendar";
import moment from "moment";
import "react-big-calendar/lib/css/react-big-calendar.css";
import { Snackbar, Stack } from "@mui/material";
import { EventHelper, SmallButton, CommonEnvironmentHelper } from "../../..";
import type { EventInterface } from "@churchapps/helpers";
import { useState, useEffect } from "react";
import { EditEventModal } from "./EditEventModal";
import { DisplayEventModal } from "./DisplayEventModal";

interface Props {
  events: EventInterface[];
  editGroupId?: string;
  churchId?: string;
  onRequestRefresh?: () => void;
}

export function EventCalendar(props: Props) {
  const localizer = momentLocalizer(moment);
  const [editEvent, setEditEvent] = useState<EventInterface | null>(null);
  const [displayEvent, setDisplayEvent] = useState<EventInterface | null>(null);
  const [open, setOpen] = useState<boolean>(false);
  const [rruleReady, setRruleReady] = useState<boolean>(false);

  useEffect(() => {
    // EventHelper.getRange uses rrule which is loaded via dynamic import.
    // Wait for it before expanding recurring events; otherwise getRange throws
    // on first render before the dynamic import resolves.
    const ensure = (EventHelper as any).ensureInitialized || (() => Promise.resolve());
    Promise.resolve(ensure()).then(() => setRruleReady(true)).catch(() => setRruleReady(true));
  }, []);

  const handleSubscribe = () => {
    setOpen(true);
    navigator.clipboard.writeText(`${CommonEnvironmentHelper.ContentApi}/events/subscribe?groupId=${props.editGroupId}&churchId=${props.churchId}`);
  };

  const handleAddEvent = (slotInfo: any) => {
    const startTime = new Date(slotInfo.start);
    startTime.setHours(12);
    startTime.setMinutes(0);
    startTime.setSeconds(0);
    const endTime = new Date(slotInfo.start);
    endTime.setHours(13);
    endTime.setMinutes(0);
    endTime.setSeconds(0);
    setEditEvent({ start: startTime, end: endTime, allDay: false, groupId: props.editGroupId, visibility: "public" });
  };

  const handleEventClick = (event: EventInterface) => {
    const ev = { ...event };
    // let tz = new Date().getTimezoneOffset();
    // ev.start = new Date(ev.start);
    // ev.end = new Date(ev.end);
    // ev.start.setMinutes(ev.start.getMinutes() - tz);
    // ev.end.setMinutes(ev.end.getMinutes() - tz);
    setDisplayEvent(ev);
    //setEditEvent(ev);
  };

  const handleDone = () => {
    setDisplayEvent(null);
    setEditEvent(null);
    if (props.onRequestRefresh) props.onRequestRefresh();
  };

  const expandedEvents: EventInterface[] = [];
  const startRange = new Date();
  const endRange = new Date();
  startRange.setFullYear(startRange.getFullYear() - 1);
  endRange.setFullYear(endRange.getFullYear() + 1);

  props.events.forEach((event) => {
    if (!event.start || !event.end) return;
    const ev = { ...event };
    ev.start = new Date(event.start);
    ev.end = new Date(event.end);
    if (event.recurrenceRule && rruleReady) {
      try {
        const dates = EventHelper.getRange(event, startRange, endRange);
        dates.forEach((date: Date) => {
          const ev = { ...event };
          if (!ev.start || !ev.end) return;
          const diff = new Date(ev.end).getTime() - new Date(ev.start).getTime();
          ev.start = date;
          ev.end = new Date(date.getTime() + diff);
          expandedEvents.push(ev);
        });
        EventHelper.removeExcludeDates(expandedEvents);
      } catch {
        // RRule not yet initialized; render single occurrence and re-render once ready.
        expandedEvents.push(ev);
      }
    } else expandedEvents.push(ev);
  });

  return (
    <div>
      {props.editGroupId
        && <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ marginBottom: 2 }}>
          <SmallButton icon="link" text="Subscribe" onClick={(e: React.MouseEvent) => { e.preventDefault(); handleSubscribe(); }} toolTip="Copy the URL and add this to your Google Calendar (or other)" />
          <SmallButton icon="event_note" text="Add Event" onClick={() => { handleAddEvent({ start: new Date(), end: new Date() }); }} />
        </Stack>
      }
      <Calendar localizer={localizer} events={expandedEvents} startAccessor="start" endAccessor="end" style={{ height: 500 }} onSelectEvent={handleEventClick} onSelectSlot={handleAddEvent} selectable={props.editGroupId !== null} />
      {editEvent && props.editGroupId && <EditEventModal event={editEvent} onDone={handleDone} />}
      {displayEvent && <DisplayEventModal event={displayEvent} onDone={handleDone} canEdit={props.editGroupId !== ""} onEdit={() => { setEditEvent(displayEvent); setDisplayEvent(null); }} />}
      <Snackbar open={open} onClose={() => setOpen(false)} autoHideDuration={2000} message={"Copied to clipboard!"} anchorOrigin={{ vertical: "bottom", horizontal: "center" }} ContentProps={{ sx: { background: "green" } }} />
    </div>
  );
}
