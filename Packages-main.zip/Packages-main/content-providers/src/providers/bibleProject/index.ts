export { BibleProjectProvider } from "./BibleProjectProvider";
